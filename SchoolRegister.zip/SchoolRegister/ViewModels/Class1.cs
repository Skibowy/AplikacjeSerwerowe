﻿namespace ViewModels
{
    public class Class1
    {

    }
}
