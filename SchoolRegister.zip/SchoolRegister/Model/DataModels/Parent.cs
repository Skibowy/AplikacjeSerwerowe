﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model.DataModels
{
    public class Parent : User
    {
        public IList<Student> Students { get; set; } = [];
    }
}
