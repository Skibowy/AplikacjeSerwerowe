﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model.DataModels
{
    public enum GradeScale
    {
        NDST = 2,
        DST = 3,
        DB = 4,
        BDB = 5
    }
}
