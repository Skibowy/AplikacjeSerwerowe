﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model.DataModels
{
    public class Student : User
    {
        public virtual Group? Group { get; set; }
        public int? GroupId { get; set; }
        public virtual IList<Grade>? Grades { get; set; }
        public virtual Parent? Parent { get; set; }
        public int? ParentId { get; set; }
        public double AverageGrade
        {
            get
            {
                if (Grades !=  null)
                {
                    foreach (var grade in Grades)
                    {
                        
                    }
                }
                return 0.0;
            }
        }
    }
}
