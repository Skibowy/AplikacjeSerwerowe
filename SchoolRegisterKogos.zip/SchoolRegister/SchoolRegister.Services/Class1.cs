﻿namespace SchoolRegister.Services
{
    public class Class1
    {

    }
}
