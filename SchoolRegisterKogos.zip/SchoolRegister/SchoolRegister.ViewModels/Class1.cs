﻿namespace SchoolRegister.ViewModels
{
    public class Class1
    {

    }
}
