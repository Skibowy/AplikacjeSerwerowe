﻿using Microsoft.AspNetCore.Identity;

namespace SchoolRegister.Model.DataModels.Roles;

public class Role : IdentityRole<int>
{
    public RoleValue RoleValue { get; set; }
    public Role(string name, RoleValue roleValue)
    {
        this.Name = name;
        this.RoleValue = roleValue;
    }
}
