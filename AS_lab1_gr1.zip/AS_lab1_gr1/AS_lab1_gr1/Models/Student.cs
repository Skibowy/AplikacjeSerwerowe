namespace AS_lab1_gr1.Models
{
    public class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public int IndexNumber{ get; set; }
        public DateTime BirthDate { get; set; }
        public string FieldOfStudy { get; set; }
    }
}
