﻿namespace AS_lab1_gr1.Models
{
    public class Class
    {
    }
}
